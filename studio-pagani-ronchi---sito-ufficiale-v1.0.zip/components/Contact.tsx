
import React from 'react';

const Contact: React.FC = () => {
  return (
    <section className="py-24 bg-soft">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          <div className="space-y-12">
            <div>
              <h2 className="text-brandGold text-sm font-bold uppercase tracking-[0.3em] mb-4">Mettiti in contatto</h2>
              <h3 className="text-4xl md:text-5xl font-serif text-primary">Dove trovarci</h3>
              <div className="w-20 h-1 bg-brandGold mt-6"></div>
            </div>

            <div className="space-y-6">
              <div className="flex gap-6 items-start">
                <div className="bg-primary p-3 rounded-xl text-white">
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-primary text-lg">Indirizzo</h4>
                  <p className="text-gray-600">Via Roma 16/G, 24060 Telgate (BG)</p>
                  <a 
                    href="https://maps.app.goo.gl/GUKLb3wGpriX7MKt7?g_st=ic" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-brandGold text-sm font-bold hover:underline"
                  >
                    Apri in Google Maps →
                  </a>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="bg-primary p-3 rounded-xl text-white">
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-primary text-lg">Contatti</h4>
                  <p className="text-gray-600">Telefono: 035 831063</p>
                  <p className="text-gray-600">WhatsApp: 338 4734667</p>
                  <p className="text-gray-600">Email: paganironchi@gmail.com</p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="bg-primary p-3 rounded-xl text-white">
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-primary text-lg">Orari di Apertura</h4>
                  <ul className="text-gray-600 text-sm space-y-1">
                    <li className="flex justify-between w-64"><span>Lun, Mar, Gio, Ven:</span> <span>09:00–13:00 | 14:00–19:00</span></li>
                    <li className="flex justify-between w-64 font-bold text-red-800"><span>Mercoledì:</span> <span>Chiuso</span></li>
                    <li className="flex justify-between w-64"><span>Sabato:</span> <span>09:00–13:00 (su appuntamento)</span></li>
                    <li className="flex justify-between w-64"><span>Domenica:</span> <span>Chiuso</span></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-gray-100">
            <h4 className="text-2xl font-serif text-primary font-bold mb-8">Prenota la tua prima visita gratuita</h4>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Nome Completo</label>
                  <input type="text" className="w-full bg-soft border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brandGold transition-all" placeholder="Mario Rossi" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Email</label>
                  <input type="email" className="w-full bg-soft border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brandGold transition-all" placeholder="email@esempio.it" />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Cellulare</label>
                  <input type="tel" className="w-full bg-soft border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brandGold transition-all" placeholder="+39 333 0000000" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Trattamento</label>
                  <select className="w-full bg-soft border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brandGold transition-all">
                    <option>Odontoiatria Pediatrica</option>
                    <option>Medicina Estetica</option>
                    <option>Ortodonzia</option>
                    <option>Implantologia</option>
                    <option>Igiene Dentale</option>
                    <option>Altro...</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Messaggio (Opzionale)</label>
                <textarea rows={4} className="w-full bg-soft border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brandGold transition-all" placeholder="Scrivi qui eventuali richieste particolari..."></textarea>
              </div>
              <button className="w-full bg-brandGold text-white font-bold py-4 rounded-xl uppercase tracking-widest hover:bg-primary transition-all shadow-lg transform active:scale-95">
                Invia Richiesta
              </button>
              <p className="text-[10px] text-gray-400 text-center uppercase tracking-tight">
                Cliccando su invia dichiari di aver letto la nostra Privacy Policy.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
