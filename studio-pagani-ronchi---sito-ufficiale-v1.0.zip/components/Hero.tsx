
import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative h-screen min-h-[600px] flex items-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://picsum.photos/id/444/1920/1080"
          alt="Studio Dentistico"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary/40"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-3xl">
          <span className="inline-block px-4 py-1 bg-brandGold text-white text-xs font-bold uppercase tracking-widest rounded-full mb-6 animate-fade-in">
            Oltre 35 anni di eccellenza
          </span>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif text-white leading-tight mb-6">
            Salute e bellezza per il tuo <span className="text-brandGold italic">sorriso</span>.
          </h1>
          <p className="text-lg md:text-xl text-gray-200 mb-10 leading-relaxed font-light">
            Benvenuti allo Studio Pagani Ronchi. Uniamo l’eccellenza dell’odontoiatria moderna 
            ai più avanzati trattamenti di medicina estetica per il benessere del tuo volto.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#contatti"
              className="px-8 py-4 bg-white text-primary font-bold rounded-full hover:bg-brandGold hover:text-white transition-all text-center uppercase tracking-widest text-sm shadow-xl"
            >
              Prenota Visita Gratuita
            </a>
            <a
              href="#trattamenti"
              className="px-8 py-4 border-2 border-white/50 text-white font-bold rounded-full hover:border-white hover:bg-white/10 transition-all text-center uppercase tracking-widest text-sm"
            >
              Scopri i Trattamenti
            </a>
          </div>
        </div>
      </div>

      {/* Stats/Badge */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-full max-w-7xl px-4 hidden lg:flex justify-between items-center text-white/70 text-xs tracking-widest uppercase font-medium">
        <div className="flex items-center gap-3">
          <div className="w-8 h-[1px] bg-brandGold"></div>
          Telgate (BG)
        </div>
        <div className="flex items-center gap-6">
          <span>Affidabilità</span>
          <span>•</span>
          <span>Tecnologia</span>
          <span>•</span>
          <span>Accoglienza</span>
        </div>
        <div className="flex items-center gap-3">
          Odontoiatria & Medicina Estetica
          <div className="w-8 h-[1px] bg-brandGold"></div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
