
import React from 'react';

interface FooterProps {
  setCurrentPage: (page: string) => void;
}

const Footer: React.FC<FooterProps> = ({ setCurrentPage }) => {
  const logoUrl = "https://i.postimg.cc/bY5P1bcv/studiopaganironchisrl.jpg";

  const treatments = [
    'Odontoiatria Pediatrica',
    'Medicina Estetica Viso',
    'Ortodonzia Invisibile',
    'Implantologia Dentale',
    'Igiene e Prevenzione',
    'Odontoiatria Conservativa',
    'Endodonzia',
    'Protesi Dentale'
  ];

  const handleNav = (page: string) => {
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };

  return (
    <footer className="bg-brandBlue text-white pt-24 pb-12 border-t-4 border-brandPink">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-16 border-b border-white/20 pb-16 mb-12 text-center md:text-left">
          
          <div className="col-span-1 flex flex-col items-center md:items-start">
            <div className="mb-8 cursor-pointer" onClick={() => handleNav('home')}>
              <div className="p-3 bg-white rounded-3xl shadow-xl overflow-hidden inline-block">
                <img src={logoUrl} alt="Logo Pagani Ronchi" className="h-24 sm:h-32 w-auto object-contain" />
              </div>
            </div>
            {/* Ridotto da font-bold a font-semibold per il testo descrittivo */}
            <p className="text-white text-lg leading-relaxed mb-8 font-semibold max-w-xs">
              Da oltre 35 anni uniamo l’eccellenza dell’odontoiatria moderna ai più avanzati trattamenti di medicina estetica.
            </p>
          </div>

          <div className="flex flex-col items-center md:items-start">
            <h5 className="font-bold uppercase tracking-[0.2em] text-sm mb-8 text-brandPink bg-white px-4 py-1.5 rounded-full w-fit">Navigazione</h5>
            <ul className="space-y-4 text-xl font-bold flex flex-col items-center md:items-start">
              <li><button onClick={() => handleNav('home')} className="hover:text-brandPink transition-colors text-white">Home</button></li>
              <li><button onClick={() => handleNav('chi-siamo')} className="hover:text-brandPink transition-colors text-white">Chi Siamo</button></li>
              <li><button onClick={() => handleNav('trattamenti')} className="hover:text-brandPink transition-colors text-white">Trattamenti</button></li>
              <li><button onClick={() => handleNav('team')} className="hover:text-brandPink transition-colors text-white">Il Team</button></li>
              <li><button onClick={() => handleNav('contatti')} className="hover:text-brandPink transition-colors text-white">Contatti</button></li>
            </ul>
          </div>

          <div className="flex flex-col items-center md:items-start">
            <h5 className="font-bold uppercase tracking-[0.2em] text-sm mb-8 text-brandPink bg-white px-4 py-1.5 rounded-full w-fit">Trattamenti</h5>
            <ul className="space-y-3 text-base text-white font-bold flex flex-col items-center md:items-start">
              {treatments.map((treatment, index) => (
                <li key={index} className="hover:text-brandPink transition-all cursor-pointer flex items-center gap-3" onClick={() => handleNav('trattamenti')}>
                  <span className="hidden md:block w-2 h-2 bg-brandPink rounded-full flex-shrink-0"></span> 
                  {treatment}
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-col items-center md:items-start">
            <h5 className="font-bold uppercase tracking-[0.2em] text-sm mb-8 text-brandPink bg-white px-4 py-1.5 rounded-full w-fit">Contatti</h5>
            <div className="space-y-6 flex flex-col items-center md:items-start">
              <div>
                <p className="text-white/80 text-[10px] font-bold uppercase mb-1 tracking-widest">Sede</p>
                <a href="https://maps.app.goo.gl/GUKLb3wGpriX7MKt7" target="_blank" rel="noopener noreferrer" className="text-white text-lg font-bold hover:text-brandPink">Via Roma 16/G, Telgate (BG)</a>
              </div>
              <div>
                <p className="text-white/80 text-[10px] font-bold uppercase mb-1 tracking-widest">Telefono</p>
                <a href="tel:035831063" className="text-2xl text-white font-bold hover:text-brandPink transition-colors">035 831063</a>
              </div>
              <div>
                <p className="text-white/80 text-[10px] font-bold uppercase mb-2 tracking-widest">WhatsApp h24</p>
                <a href="https://wa.me/393384734667" target="_blank" rel="noopener noreferrer" className="inline-block"><p className="text-2xl text-brandPink bg-white px-5 py-2 rounded-2xl w-fit shadow-2xl font-bold hover:bg-brandPink hover:text-white">338 4734667</p></a>
              </div>
              <div>
                <a href="mailto:paganironchi@gmail.com" className="text-white text-base lowercase underline font-bold tracking-wider hover:text-brandPink">paganironchi@gmail.com</a>
              </div>
            </div>
          </div>

        </div>

        <div className="flex flex-col md:flex-row justify-between items-center text-[9px] md:text-[10px] text-center uppercase tracking-[0.3em] text-white/60 font-bold gap-4">
          <p>© 2024 Studio Dentistico Pagani Ronchi. Tutti i diritti riservati.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
