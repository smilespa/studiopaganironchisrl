
import React from 'react';

const treatmentData = [
  {
    title: 'Odontoiatria Pediatrica',
    desc: 'Approccio sereno e giocoso per prevenire la paura del dentista.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    title: 'Medicina Estetica',
    desc: 'Botox, filler e biostimolazioni per valorizzare il volto in modo naturale.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
  },
  {
    title: 'Ortodonzia',
    desc: 'Allineamento dentale per bambini e adulti con attenzione funzionale ed estetica.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
  },
  {
    title: 'Implantologia',
    desc: 'Soluzioni fisse d’avanguardia con materiali biocompatibili.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.628.282a2 2 0 01-1.806 0l-.628-.282a6 6 0 00-3.86-.517l-2.387.477a2 2 0 00-1.022.547l-1.162 1.626a2 2 0 00.339 2.597l1.574 1.574a2 2 0 002.597.339l1.626-1.162a2 2 0 011.602 0l1.626 1.162a2 2 0 002.597-.339l1.574-1.574a2 2 0 00.339-2.597l-1.162-1.626z" />
      </svg>
    ),
  },
  {
    title: 'Igiene e Profilassi',
    desc: 'Pulizia professionale e programmi di prevenzione personalizzati.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
      </svg>
    ),
  },
  {
    title: 'Conservativa',
    desc: 'Cura delle carie e restauri estetici con materiali di ultima generazione.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-7.714 2.143L11 21l-2.286-6.857L1 12l7.714-2.143L11 3z" />
      </svg>
    ),
  },
  {
    title: 'Endodonzia',
    desc: 'Trattamenti canalari per salvare i denti compromessi.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    title: 'Protesi Fissa e Mobile',
    desc: 'Soluzioni protesiche personalizzate per estetica e funzionalità.',
    icon: (
      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
      </svg>
    ),
  },
];

const Treatments: React.FC = () => {
  return (
    <section className="py-24 bg-soft">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-brandGold text-sm font-bold uppercase tracking-[0.3em] mb-4">Cura e Innovazione</h2>
          <h3 className="text-4xl md:text-5xl font-serif text-primary">I Nostri Trattamenti</h3>
          <div className="w-24 h-1 bg-brandGold mx-auto mt-6"></div>
          <p className="mt-6 text-gray-500 max-w-2xl mx-auto italic">
            Dall'odontoiatria d'avanguardia alla medicina estetica, ci prendiamo cura del tuo sorriso a 360 gradi.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {treatmentData.map((item, index) => (
            <div 
              key={index} 
              className="bg-white p-10 rounded-2xl shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300 group border-b-4 border-transparent hover:border-brandGold"
            >
              <div className="w-16 h-16 bg-soft rounded-2xl flex items-center justify-center text-brandGold mb-6 group-hover:bg-brandGold group-hover:text-white transition-colors duration-300">
                {item.icon}
              </div>
              <h4 className="text-xl font-bold text-primary mb-3">{item.title}</h4>
              <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a
            href="#contatti"
            className="inline-block bg-primary text-white px-10 py-4 rounded-full font-bold uppercase tracking-widest text-xs hover:bg-secondary transition-all shadow-lg"
          >
            Chiedi informazioni sui trattamenti
          </a>
        </div>
      </div>
    </section>
  );
};

export default Treatments;
