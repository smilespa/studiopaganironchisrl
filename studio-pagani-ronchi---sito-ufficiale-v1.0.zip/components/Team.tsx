
import React from 'react';

const teamMembers = [
  { name: 'Tiziana Pagani', role: 'Fondatrice e Direttore Sanitario', image: 'https://picsum.photos/id/1027/400/500' },
  { name: 'Valerio Ronchi', role: 'Odontoiatra', image: 'https://picsum.photos/id/1005/400/500' },
  { name: 'Dr. Rossi', role: 'Collaboratore Odontoiatra', image: 'https://picsum.photos/id/64/400/500' },
  { name: 'Dr.ssa Bianchi', role: 'Medicina Estetica', image: 'https://picsum.photos/id/65/400/500' },
  { name: 'Assis. Maria', role: 'Assistente alla poltrona', image: 'https://picsum.photos/id/66/400/500' },
  { name: 'Assis. Elena', role: 'Assistente alla poltrona', image: 'https://picsum.photos/id/67/400/500' },
  { name: 'Segr. Giulia', role: 'Amministrazione', image: 'https://picsum.photos/id/68/400/500' },
];

const Team: React.FC = () => {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-brandGold text-sm font-bold uppercase tracking-[0.3em] mb-4">Competenza e Dedizione</h2>
          <h3 className="text-4xl md:text-5xl font-serif text-primary">Il Nostro Team</h3>
          <div className="w-24 h-1 bg-brandGold mx-auto mt-6"></div>
        </div>

        {/* Main Founders */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20 max-w-5xl mx-auto">
          {teamMembers.slice(0, 2).map((member, index) => (
            <div key={index} className="group">
              <div className="aspect-[4/5] rounded-2xl overflow-hidden mb-6 shadow-lg">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <h4 className="text-2xl font-serif text-primary font-bold">{member.name}</h4>
              <p className="text-brandGold font-semibold uppercase tracking-widest text-sm mt-1">{member.role}</p>
              <p className="mt-4 text-gray-500 leading-relaxed text-sm">
                Con oltre tre decenni di esperienza, guida lo studio con passione e rigore scientifico, garantendo il massimo standard qualitativo.
              </p>
            </div>
          ))}
        </div>

        {/* Other Team Members */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
          {teamMembers.slice(2).map((member, index) => (
            <div key={index} className="text-center">
              <div className="aspect-square rounded-full overflow-hidden mb-4 shadow-md max-w-[160px] mx-auto ring-4 ring-soft group-hover:ring-brandGold transition-all">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <h5 className="font-bold text-primary text-sm">{member.name}</h5>
              <p className="text-gray-500 text-xs uppercase tracking-tighter mt-1">{member.role}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Team;
