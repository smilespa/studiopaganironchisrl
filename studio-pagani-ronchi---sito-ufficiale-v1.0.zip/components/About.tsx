
import React from 'react';

const About: React.FC = () => {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://picsum.photos/id/1012/800/1000"
                alt="Studio Pagani Ronchi"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Experience badge */}
            <div className="absolute -bottom-8 -right-8 bg-brandGold text-white p-8 rounded-2xl shadow-xl hidden md:block">
              <p className="text-5xl font-serif font-bold mb-1">35+</p>
              <p className="text-xs uppercase tracking-widest font-semibold">Anni di Esperienza</p>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h2 className="text-brandGold text-sm font-bold uppercase tracking-[0.3em] mb-3">L'eccellenza a Telgate</h2>
              <h3 className="text-3xl md:text-5xl font-serif text-primary mb-6">Puoi tornare a sorridere.</h3>
              <div className="w-20 h-1 bg-brandGold mb-8"></div>
            </div>
            
            <p className="text-lg text-gray-600 leading-relaxed italic">
              "Lo Studio Pagani Ronchi è un punto di riferimento a Telgate da oltre 35 anni, sinonimo di competenza clinica, affidabilità e attenzione autentica al paziente."
            </p>
            
            <div className="space-y-4 text-gray-600 leading-relaxed">
              <p>
                Integriamo odontoiatria moderna e medicina estetica, offrendo percorsi personalizzati per il benessere e l’armonia del volto. Fondato da <strong>Tiziana Pagani</strong> e <strong>Valerio Ronchi</strong>, lo studio mantiene una linea chiara: qualità clinica elevata, tecnologie all’avanguardia e accoglienza autentica.
              </p>
              <p>
                Crediamo che un sorriso sano sia la base di una bellezza naturale. Per questo motivo, ogni trattamento è studiato per rispettare l'unicità di ogni volto, garantendo risultati duraturi e armoniosi.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-8 pt-8 border-t border-gray-100">
              <div>
                <p className="text-primary font-bold text-lg">Qualità Clinica</p>
                <p className="text-gray-500 text-sm">Protocolli rigorosi e materiali certificati.</p>
              </div>
              <div>
                <p className="text-primary font-bold text-lg">Integrazione Estetica</p>
                <p className="text-gray-500 text-sm">Oltre il dente, per l'armonia del viso.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
