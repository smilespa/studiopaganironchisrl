
import React, { useState } from 'react';

interface NavbarProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentPage, setCurrentPage }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: 'Home', id: 'home' },
    { name: 'Chi Siamo', id: 'chi-siamo' },
    { name: 'Trattamenti', id: 'trattamenti' },
    { name: 'Team', id: 'team' },
    { name: 'Contatti', id: 'contatti' },
  ];

  const logoUrl = "https://i.postimg.cc/nc8V95Dz/studio-dentistico-pagani-ronchi-srl-logo-2.png";

  const handlePageChange = (id: string) => {
    setCurrentPage(id);
    setIsOpen(false);
    window.scrollTo(0, 0);
  };

  return (
    <nav className="fixed top-0 w-full z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Altezza barra costante: h-24 (96px) mobile, h-28 (112px) desktop */}
        <div className="flex items-center justify-between h-24 sm:h-28 relative">
          
          {/* Logo Container con effetto Hanging */}
          <div className="flex-1 flex items-center justify-center md:justify-start h-full overflow-visible">
            <div 
              className="cursor-pointer flex items-center h-full relative z-10" 
              onClick={() => handlePageChange('home')}
            >
              <img 
                src={logoUrl} 
                alt="Logo Studio Dentistico Pagani Ronchi" 
                className="h-32 sm:h-40 w-auto max-w-none object-contain transition-all duration-300 transform hover:scale-105 drop-shadow-lg"
              />
            </div>
          </div>

          {/* Mobile Toggle */}
          <div className="md:hidden absolute right-0">
            <button 
              onClick={() => setIsOpen(!isOpen)} 
              className="text-brandBlue p-2"
              aria-label="Apri Menu"
            >
              {isOpen ? (
                <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path d="M6 18L18 6M6 6l12 12" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              ) : (
                <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path d="M4 6h16M4 12h16M4 18h16" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </button>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handlePageChange(link.id)}
                className={`text-[11px] font-bold uppercase tracking-widest transition-all duration-300 relative group ${
                  currentPage === link.id ? 'text-brandPink' : 'text-brandBlue hover:text-brandPink'
                }`}
              >
                {link.name}
                <span className={`absolute -bottom-1 left-0 w-full h-0.5 bg-brandPink transform origin-left transition-transform duration-300 ${currentPage === link.id ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div 
        className={`md:hidden absolute w-full bg-white border-t border-gray-100 shadow-2xl transition-all duration-300 transform ${
          isOpen ? 'translate-y-0 opacity-100' : '-translate-y-4 opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex flex-col items-center py-10 space-y-6">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handlePageChange(link.id)}
              className={`text-sm font-bold uppercase tracking-widest ${
                currentPage === link.id ? 'text-brandPink' : 'text-brandBlue'
              }`}
            >
              {link.name}
            </button>
          ))}
          <button
            onClick={() => handlePageChange('contatti')}
            className="mt-2 bg-brandPink text-white px-10 py-4 rounded-xl text-[10px] font-bold uppercase tracking-widest shadow-lg"
          >
            Prenota Ora
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
