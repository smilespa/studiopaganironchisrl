
# Studio Dentistico Pagani Ronchi - Guida alla Pubblicazione

Questo progetto è pronto per essere messo online. Segui una di queste procedure:

## 1. Pubblicazione Rapida (Netlify / Vercel)
1. Esporta il progetto come ZIP.
2. Estrai la cartella sul tuo computer.
3. Vai su [Netlify Drop](https://app.netlify.com/drop).
4. Trascina la cartella nel browser.
5. Il sito è online!

## 2. Pubblicazione via GitHub (Automatica)
1. Crea un nuovo repository su GitHub.
2. Carica questi file.
3. Vai in `Settings > Pages`.
4. Sotto "Build and deployment" > "Source", seleziona **GitHub Actions**.
5. Ad ogni tua modifica caricata su GitHub, il sito si aggiornerà da solo.

## 3. Requisiti Tecnici
Il sito è costruito con:
- React 19
- Vite (Build tool)
- Tailwind CSS (Styling)

Per lo sviluppo locale:
```bash
npm install
npm run dev
```
