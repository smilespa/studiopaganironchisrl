
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import About from './pages/About';
import Treatments from './pages/Treatments';
import Team from './pages/Team';
import Contact from './pages/Contact';
import Footer from './components/Footer';
import FloatingCTA from './components/FloatingCTA';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState('home');

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  const renderPage = () => {
    switch(currentPage) {
      case 'home': return <Home onNavigate={setCurrentPage} />;
      case 'chi-siamo': return <About />;
      case 'trattamenti': return <Treatments />;
      case 'team': return <Team />;
      case 'contatti': return <Contact />;
      default: return <Home onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar currentPage={currentPage} setCurrentPage={setCurrentPage} />
      {/* pt-24 per mobile, sm:pt-28 per desktop per accomodare le nuove dimensioni della barra */}
      <main className="flex-grow pt-24 sm:pt-28 page-enter">
        {renderPage()}
      </main>
      <Footer setCurrentPage={setCurrentPage} />
      <FloatingCTA />
    </div>
  );
};

export default App;
