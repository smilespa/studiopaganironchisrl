
import React from 'react';

const treatmentList = [
  { title: 'Odontoiatria Pediatrica', desc: 'Approccio sereno per i più piccoli fin dai primi anni.' },
  { title: 'Medicina Estetica Viso', desc: 'Trattamenti di filler e botox per l’armonia del volto.' },
  { title: 'Ortodonzia Invisibile', desc: 'Allineamento moderno con mascherine trasparenti.' },
  { title: 'Implantologia Dentale', desc: 'Impianti biocompatibili per ritrovare funzione ed estetica.' },
  { title: 'Igiene e Prevenzione', desc: 'Programmi per mantenere denti e gengive sani nel tempo.' },
  { title: 'Odontoiatria Conservativa', desc: 'Cura delle carie con materiali estetici di ultima generazione.' },
  { title: 'Endodonzia', desc: 'Trattamenti canalari per salvare denti compromessi.' },
  { title: 'Protesi Dentale', desc: 'Soluzioni fisse o mobili per una masticazione perfetta.' },
];

const Treatments: React.FC = () => {
  return (
    <section className="bg-white py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <header className="mb-20 flex flex-col items-center">
          <h1 className="text-3xl md:text-6xl font-bold text-brandBlue mb-4 uppercase tracking-tight">I Nostri Trattamenti</h1>
          <div className="w-16 h-1.5 bg-brandPink mb-6"></div>
          <p className="max-w-2xl text-gray-500 font-medium italic">Eccellenza clinica e medicina estetica integrata.</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {treatmentList.map((item, i) => (
            <article key={i} className="p-8 rounded-[40px] bg-light border border-gray-100 hover:bg-white hover:shadow-2xl transition-all duration-300">
              <h2 className="text-lg font-bold text-brandBlue mb-4 uppercase tracking-tighter">{item.title}</h2>
              <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Treatments;
