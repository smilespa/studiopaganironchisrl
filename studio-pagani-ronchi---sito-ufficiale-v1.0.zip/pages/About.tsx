
import React from 'react';

const IMAGES = {
  studio1: "https://i.postimg.cc/mDPJ8XCQ/team-studio-pagani-ronchi.jpg",
  studio2: "https://i.postimg.cc/Y0pgtVRz/la-tua-sicurezza-la-nostra-cura-studio-pagani-ronchi.jpg"
};

const About: React.FC = () => {
  return (
    <div className="bg-white py-16 md:py-20 overflow-x-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center lg:text-left flex flex-col items-center lg:items-start">
          <h1 className="text-brandBlue text-[10px] font-bold uppercase tracking-widest mb-4">Eccellenza a Telgate</h1>
          <h2 className="text-3xl md:text-6xl font-bold text-brandPink mb-8 leading-tight">Puoi tornare a sorridere.</h2>
          <div className="w-16 h-1.5 bg-brandBlue mb-10"></div>

          <div className="space-y-10 text-base text-gray-600 leading-relaxed font-medium">
            <p className="text-lg md:text-2xl text-brandBlue font-bold italic border-brandPink lg:border-l-4 lg:pl-8 py-2">
              "Lo Studio Pagani Ronchi è sinonimo di competenza clinica e attenzione autentica al paziente."
            </p>
            <p>
              Fondato da <strong>Tiziana Pagani</strong> e <strong>Valerio Ronchi</strong>, lo studio offre tecnologie all’avanguardia e un’accoglienza che mette davvero a proprio agio.
            </p>
          </div>
        </div>

        <div className="mt-20 flex flex-col md:grid md:grid-cols-2 gap-0 md:gap-12 items-center -mx-4 md:mx-0">
            <div className="w-full">
              <img 
                src={IMAGES.studio1} 
                className="w-full h-auto md:h-96 md:rounded-[32px] md:object-cover shadow-md md:shadow-xl" 
                alt="Interno Studio Pagani Ronchi" 
              />
            </div>
            <div className="w-full mt-4 md:mt-0">
              <img 
                src={IMAGES.studio2} 
                className="w-full h-auto md:h-96 md:rounded-[32px] md:object-cover shadow-md md:shadow-xl" 
                alt="Ambiente Clinico" 
              />
            </div>
        </div>
      </div>
    </div>
  );
};

export default About;
