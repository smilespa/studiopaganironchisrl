
import React from 'react';

const IMAGES = {
  tizianaPagani: "https://i.postimg.cc/zvjm4Lt6/dottoressa-tiziana-pagani-studio-Pagani-ronchi.png",
  valerioRonchi: "https://i.postimg.cc/KvSR2C9f/dottor-valerio-ronchi-studio-dentistico.jpg"
};

const staffMembers = [
  { name: 'Stefano Ronchi', role: 'Odontoiatra', category: 'Odontoiatri' },
  { name: 'Mauro Giglio', role: 'Odontoiatra Estetico', category: 'Odontoiatri' },
  { name: 'Lara Sartori', role: 'Medico Estetico', category: 'Medicina Estetica' },
  { name: 'Carlo Manenti', role: 'Igienista Dentale', category: 'Igiene' },
  { name: 'Marzia Pasquali', role: 'Assistente alla Poltrona', category: 'Assistenza' },
  { name: 'Alessandra C.', role: 'Assistente alla Poltrona', category: 'Assistenza' },
  { name: 'Nicole Ghilardi', role: 'Assistente alla Poltrona', category: 'Assistenza' },
];

const Team: React.FC = () => {
  return (
    <div className="bg-white py-16 md:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20 flex flex-col items-center">
          <h1 className="text-4xl md:text-6xl font-bold text-brandBlue mb-4 uppercase">Il Team</h1>
          <div className="w-16 h-1.5 bg-brandPink"></div>
          <p className="mt-6 text-gray-500 max-w-2xl font-medium">L'eccellenza dello Studio Pagani Ronchi è garantita da un team affiatato di specialisti dediti alla cura del tuo sorriso.</p>
        </div>

        {/* Fondatori Centrati */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 mb-32 max-w-4xl mx-auto">
          <div className="flex flex-col items-center text-center">
            <div className="w-32 h-32 md:w-64 md:h-64 rounded-full md:rounded-[40px] overflow-hidden mb-6 shadow-xl border-4 border-white">
              <img src={IMAGES.tizianaPagani} className="w-full h-full object-cover" alt="Tiziana Pagani" />
            </div>
            <h3 className="text-2xl font-bold text-brandBlue mb-1 uppercase tracking-tight">Tiziana Pagani</h3>
            <p className="text-brandPink font-bold text-[10px] uppercase tracking-widest">Fondatrice e Odontoiatra</p>
          </div>

          <div className="flex flex-col items-center text-center">
            <div className="w-32 h-32 md:w-64 md:h-64 rounded-full md:rounded-[40px] overflow-hidden mb-6 shadow-xl border-4 border-white">
              <img src={IMAGES.valerioRonchi} className="w-full h-full object-cover" alt="Valerio Ronchi" />
            </div>
            <h3 className="text-2xl font-bold text-brandBlue mb-1 uppercase tracking-tight">Valerio Ronchi</h3>
            <p className="text-brandPink font-bold text-[10px] uppercase tracking-widest">Fondatore e Odontoiatra</p>
          </div>
        </div>

        {/* Staff Diviso per Categorie */}
        <div className="max-w-5xl mx-auto space-y-20">
          
          {/* Medici e Specialisti */}
          <section>
            <h4 className="text-center text-xs font-bold text-brandBlue uppercase tracking-[0.3em] mb-12 flex items-center justify-center gap-4">
              <span className="h-px w-12 bg-gray-200"></span>
              Medici e Collaboratori
              <span className="h-px w-12 bg-gray-200"></span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {staffMembers.filter(m => m.category !== 'Assistenza').map((member, i) => (
                <div key={i} className="bg-light p-8 rounded-[32px] text-center border border-gray-50 hover:shadow-lg transition-all">
                  <p className="text-lg font-bold text-brandBlue mb-1">{member.name}</p>
                  <p className="text-brandPink text-[10px] font-bold uppercase tracking-widest">{member.role}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Assistenti alla Poltrona */}
          <section>
            <h4 className="text-center text-xs font-bold text-brandBlue uppercase tracking-[0.3em] mb-12 flex items-center justify-center gap-4">
              <span className="h-px w-12 bg-gray-200"></span>
              Assistenza alla Poltrona
              <span className="h-px w-12 bg-gray-200"></span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {staffMembers.filter(m => m.category === 'Assistenza').map((member, i) => (
                <div key={i} className="p-6 rounded-2xl bg-white border border-gray-100 text-center shadow-sm">
                  <p className="text-base font-bold text-gray-800 mb-1">{member.name}</p>
                  <p className="text-gray-400 text-[9px] font-bold uppercase tracking-widest">{member.role}</p>
                </div>
              ))}
            </div>
          </section>

        </div>
      </div>
    </div>
  );
};

export default Team;
