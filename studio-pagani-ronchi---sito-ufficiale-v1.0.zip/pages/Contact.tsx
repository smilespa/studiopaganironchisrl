
import React from 'react';

const Contact: React.FC = () => {
  return (
    <section className="bg-white py-16 md:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center text-center space-y-16">
          
          <header className="flex flex-col items-center max-w-2xl">
            <h1 className="text-3xl md:text-5xl font-bold text-brandBlue mb-4 uppercase">Contatti e Sede</h1>
            <div className="w-16 h-1.5 bg-brandPink mb-8"></div>
            <p className="text-gray-500 font-medium">Ci trovi a Telgate (BG) in Via Roma 16/G. Prenota subito il tuo appuntamento.</p>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 w-full items-start">
             {/* Info Centered */}
             <div className="space-y-10 flex flex-col items-center md:items-start text-center md:text-left">
                <div>
                  <h4 className="text-xs font-bold text-brandPink uppercase tracking-widest mb-3">Indirizzo</h4>
                  <a href="https://maps.app.goo.gl/GUKLb3wGpriX7MKt7" target="_blank" rel="noreferrer" className="text-xl md:text-2xl font-bold text-brandBlue">📍 Via Roma 16/G, Telgate</a>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-brandPink uppercase tracking-widest mb-3">Telefono</h4>
                  <a href="tel:035831063" className="text-xl md:text-2xl font-bold text-brandBlue">📞 035 831063</a>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-brandPink uppercase tracking-widest mb-3">WhatsApp</h4>
                  <a href="https://wa.me/393384734667" target="_blank" rel="noreferrer" className="text-xl md:text-2xl font-bold text-brandPink">💬 338 4734667</a>
                </div>
             </div>

             {/* Orari Centered */}
             <div className="bg-light p-8 rounded-[32px] w-full max-w-sm mx-auto md:max-w-none">
                <h4 className="text-xs font-bold text-brandBlue uppercase mb-6">Orari Studio</h4>
                <div className="space-y-4 text-xs font-bold text-gray-600">
                  <div className="flex justify-between border-b pb-2"><span>LUN, MAR, GIO, VEN</span> <span>09–13 | 14–19</span></div>
                  <div className="flex justify-between border-b pb-2 text-red-500"><span>MERCOLEDÌ</span> <span>CHIUSO</span></div>
                  <div className="flex justify-between border-b pb-2"><span>SABATO</span> <span>09–13*</span></div>
                  <div className="flex justify-center pt-2"><span className="text-[8px] italic">*Un sabato al mese, su appuntamento</span></div>
                </div>
             </div>
          </div>

          <div className="w-full h-64 md:h-96 rounded-[32px] overflow-hidden shadow-2xl">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2786.537227441113!2d9.9186!3d45.6264!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478143615456f937%3A0x77636e0d37e6f83!2sVia%20Roma%2C%2016%2C%2024060%20Telgate%20BG!5e0!3m2!1sit!2sit!4v1710000000000!5m2!1sit!2sit" 
              width="100%" height="100%" style={{ border: 0 }} loading="lazy" title="Mappa"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
