
import React from 'react';

interface HomeProps {
  onNavigate: (page: string) => void;
}

const IMAGES = {
  hero1: "https://i.postimg.cc/mk9FT4f6/sala-di-attesa-studio-pagani-ronchi-telgate-srl.jpg",
  hero2: "https://i.postimg.cc/J05d69YW/studio-dentistico-oagani-ronchi-igiene-orale.jpg",
  hero3: "https://i.postimg.cc/RVnWt4Y7/studio-dentistico-pagani-ronchi-srl.jpg",
  hero4: "https://i.postimg.cc/rw0NzBGz/reception-studio-dentistico-pagani-ronchi-srl.jpg"
};

const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  return (
    <div className="bg-white">
      <section className="relative min-h-[85vh] flex items-center overflow-hidden bg-white">
        {/* Background Grid */}
        <div className="absolute inset-0 w-full h-full grid grid-cols-2 grid-rows-2 gap-1 md:gap-2 p-1 md:p-4 opacity-60 md:opacity-100 z-0" aria-hidden="true">
            <img src={IMAGES.hero1} className="w-full h-full object-cover rounded-lg md:rounded-2xl shadow-sm" alt="Sala attesa" />
            <img src={IMAGES.hero2} className="w-full h-full object-cover rounded-lg md:rounded-2xl shadow-sm" alt="Igiene" />
            <img src={IMAGES.hero3} className="w-full h-full object-cover rounded-lg md:rounded-2xl shadow-sm" alt="Studio" />
            <img src={IMAGES.hero4} className="w-full h-full object-cover rounded-lg md:rounded-2xl shadow-sm" alt="Reception" />
        </div>

        <div className="absolute inset-0 bg-white/60 md:bg-transparent md:bg-gradient-to-r md:from-white md:via-white/90 md:to-white/20 pointer-events-none z-10"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-20 py-16 md:py-24">
          <header className="flex flex-col items-center md:items-start text-center md:text-left md:max-w-2xl lg:max-w-3xl">
            {/* Titolo meno spesso (font-bold invece di font-black) */}
            <h1 className="text-4xl md:text-7xl font-bold text-brandBlue leading-[1.1] mb-8 drop-shadow-sm">
              Studio <span className="text-brandPink">Pagani Ronchi</span>
            </h1>
            <div className="bg-white/70 backdrop-blur-md p-6 rounded-3xl md:bg-transparent md:backdrop-blur-none md:p-0 md:rounded-none mb-10">
              <p className="text-lg md:text-xl text-gray-800 leading-relaxed font-semibold">
                Da oltre 35 anni uniamo l’eccellenza dell’<strong>odontoiatria moderna</strong> ai più avanzati trattamenti di <strong>medicina estetica</strong> a Telgate (BG).
              </p>
            </div>
            <button 
              onClick={() => onNavigate('contatti')}
              className="w-full md:w-fit px-12 py-6 bg-brandPink text-white font-bold text-sm uppercase tracking-widest rounded-2xl hover:bg-brandBlue transition-all shadow-2xl active:scale-95 border-b-4 border-black/10"
            >
              Prima visita gratuita
            </button>
          </header>
        </div>
      </section>

      {/* Stats Section con font bilanciato */}
      <section className="py-12 bg-light border-y border-gray-100 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-10 text-center">
              {[
                { val: "35+", label: "Anni di Esperienza" },
                { val: "100%", label: "Qualità Certificata" },
                { val: "Digitale", label: "Tecnologia 3D" },
                { val: "Gratis", label: "Prima visita" }
              ].map((stat, i) => (
                <article key={i}>
                  <p className="text-3xl font-bold text-brandBlue mb-1">{stat.val}</p>
                  <p className="text-[9px] font-bold uppercase tracking-widest text-brandPink">{stat.label}</p>
                </article>
              ))}
           </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
